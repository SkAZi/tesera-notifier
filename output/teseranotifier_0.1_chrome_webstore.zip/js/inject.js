// ==UserScript==
// @name TeseraTweaks
// @include http://tesera.ru/*
// @include https://tesera.ru/*
// ==/UserScript==

console.log('Tweaked!');
