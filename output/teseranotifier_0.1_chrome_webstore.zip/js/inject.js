// ==UserScript==
// @name TeseraTweaks
// @include http://tesera.ru/*
// ==/UserScript==

console.log('Tweaked!');
